<?php
session_start();
$dbHost = 'localhost';
$dbName = 'BH';
$dbUsername = 'root';
$dbPassword = '';
$dbc= mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName); 
?>