CREATE TABLE ff (
  `file` varchar(255) DEFAULT NULL,
  `uploadername` varchar(255) DEFAULT NULL,
)