<?php
include("config.php");
if(isset($_GET['submit'])){
    $name= $_GET['uploadername'];
    $file= $_GET['file'];
    $sql ="insert into ff (uploadername,file) values('$name','$file')";
   
    $result = mysqli_query($dbc,"INSERT into ff(uploadername,file) values('$name','$file')");

    if($result)
{
$done=2; 
}
else{
$error[] ='Failed : Something went wrong';
}
}

    
    ?>
    


    <!DOCTYPE html>
<?php require_once("config.php"); ?>
<html>
<head><br>
<title> Login</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-4">
		</div>
		<div class="col-sm-4">
			<div class="login_form">
 	<form action="" method="POST">
  <div class="form-group">



    


    <form action="" method="GET">
<div class="form-group">
    <label class="label_txt">upload file </label>
    <input type="file" class="form-control" name="file">
  </div>
  <div class="form-group">
  <label class="label_txt">uploader name</label>
    <input type="text" class="form-control" name="uploadername">
    </div>
    <input type="submit" name="submit" value="submit"  class="btn btn-primary btn-group-lg form_btn">
  </div>
  </div>
  </div>
</div>
</body>
  </html>
